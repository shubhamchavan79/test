import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoaderComponent } from './loader/loader.component';
import { ToasterComponent } from './toaster/toaster.component';



@NgModule({
  declarations: [
    LoaderComponent,
    ToasterComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    LoaderComponent,
    ToasterComponent
  ]
})
export class SharedModule { }
